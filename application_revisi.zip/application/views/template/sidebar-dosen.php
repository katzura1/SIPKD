
            <li class="header">MENU DOSEN</li>
            <li class="treeview">
                <a href="#">
                    <i class="fa fa-bookmark-o"></i> <span>Penunjang</span> <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li><a href="<?php echo site_url('penunjang/list_penunjang') ?>"><i class="fa fa-circle-o"></i>List Penunjang</a></li>
                </ul>
            </li>
            <li class="treeview">
                <a href="#">
                    <i class="fa fa-graduation-cap"></i> <span>Laporan</span> <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li><a href="<?php echo site_url('kinerja_dosen/nilai_dosen') ?>"><i class="fa fa-circle-o"></i>Kinerja Personal</a></li>
                </ul>
            </li>
