
            <li class="header">MENU BAA</li>
            <li class="treeview">
                <a href="#">
                    <i class="fa fa-dashboard"></i> <span>Input Kegiatan Akademik</span> <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li><a href="<?=site_url('kegiatan_akademik/upload_materi')?>"><i class="fa fa-circle-o"></i>Ketepatan Upload Materi</a></li>
                    <li><a href="<?=site_url('kegiatan_akademik/upload_soal') ?>"><i class="fa fa-circle-o"></i>Ketepatan Upload Soal</a></li>
                    <li><a href="<?=site_url('kegiatan_akademik/upload_nilai') ?>"><i class="fa fa-circle-o"></i>Ketepatan Upload Nilai</a></li>
                </ul>
            </li>
